# Market Analyst

Combined package with one local tactic and LLLM network channel declarations. It is
used to test mixed LLLM/LLLM network package composition over deterministic data.
